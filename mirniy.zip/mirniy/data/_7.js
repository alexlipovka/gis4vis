var json__7 = {
"type": "FeatureCollection",
"name": "_7",
"crs": { "type": "name", "properties": { "name": "urn:ogc:def:crs:OGC:1.3:CRS84" } },
"features": [
{ "type": "Feature", "properties": { "Name      ": "Прибор учета", "H_geo     ": 373.15 }, "geometry": { "type": "Point", "coordinates": [ 113.99041162295174, 62.54688729836802 ] } },
{ "type": "Feature", "properties": { "Name      ": "Прибор учета", "H_geo     ": 318.84 }, "geometry": { "type": "Point", "coordinates": [ 113.966017782700874, 62.524683487123148 ] } },
{ "type": "Feature", "properties": { "Name      ": "Прибор учета", "H_geo     ": 344.11 }, "geometry": { "type": "Point", "coordinates": [ 113.966806757917269, 62.526280952843969 ] } },
{ "type": "Feature", "properties": { "Name      ": "Прибор учета", "H_geo     ": 343.96 }, "geometry": { "type": "Point", "coordinates": [ 113.966786613103807, 62.526272769013502 ] } },
{ "type": "Feature", "properties": { "Name      ": "Прибор учета", "H_geo     ": 323.71 }, "geometry": { "type": "Point", "coordinates": [ 113.964979695282338, 62.524864610579868 ] } },
{ "type": "Feature", "properties": { "Name      ": "Прибор учета", "H_geo     ": 317.87 }, "geometry": { "type": "Point", "coordinates": [ 113.966222738191377, 62.524687444140078 ] } },
{ "type": "Feature", "properties": { "Name      ": "Прибор учета", "H_geo     ": 324.35 }, "geometry": { "type": "Point", "coordinates": [ 113.965024571451607, 62.524871265562886 ] } },
{ "type": "Feature", "properties": { "Name      ": "Прибор учета", "H_geo     ": 317.76 }, "geometry": { "type": "Point", "coordinates": [ 113.966199175954202, 62.524682857597725 ] } },
{ "type": "Feature", "properties": { "Name      ": "Прибор учета", "H_geo     ": 368.95 }, "geometry": { "type": "Point", "coordinates": [ 113.967558321337236, 62.528043983750408 ] } },
{ "type": "Feature", "properties": { "Name      ": "Прибор учета", "H_geo     ": 368.69 }, "geometry": { "type": "Point", "coordinates": [ 113.967574239337154, 62.528050099140202 ] } }
]
}
