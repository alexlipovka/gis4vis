var json__4 = {
"type": "FeatureCollection",
"name": "_4",
"crs": { "type": "name", "properties": { "name": "urn:ogc:def:crs:OGC:1.3:CRS84" } },
"features": [
{ "type": "Feature", "properties": { }, "geometry": { "type": "MultiLineString", "coordinates": [ [ [ 113.983585768748597, 62.548244824971398 ], [ 113.983697734341263, 62.548201027988561 ] ] ] } },
{ "type": "Feature", "properties": { }, "geometry": { "type": "MultiLineString", "coordinates": [ [ [ 113.976120046921537, 62.545110327970129 ], [ 113.976019502718643, 62.54503577417389 ] ] ] } },
{ "type": "Feature", "properties": { }, "geometry": { "type": "MultiLineString", "coordinates": [ [ [ 113.935843819902644, 62.522918117979437 ], [ 113.935872957936397, 62.522898602691399 ], [ 113.936037354003375, 62.522864788183092 ] ] ] } },
{ "type": "Feature", "properties": { }, "geometry": { "type": "MultiLineString", "coordinates": [ [ [ 113.969647356479328, 62.525225688374668 ], [ 113.969497619361434, 62.52524592312033 ] ] ] } },
{ "type": "Feature", "properties": { }, "geometry": { "type": "MultiLineString", "coordinates": [ [ [ 113.987006340087419, 62.512776823182705 ], [ 113.986933944664045, 62.512731857081235 ] ] ] } },
{ "type": "Feature", "properties": { }, "geometry": { "type": "MultiLineString", "coordinates": [ [ [ 113.974905602453035, 62.539680581285417 ], [ 113.974853621639724, 62.539623654200959 ], [ 113.974697859064236, 62.539642719827981 ] ] ] } },
{ "type": "Feature", "properties": { }, "geometry": { "type": "MultiLineString", "coordinates": [ [ [ 113.975490521500959, 62.542203089645682 ], [ 113.975420374382665, 62.542208935238875 ], [ 113.975341323976281, 62.54221972710323 ] ] ] } },
{ "type": "Feature", "properties": { }, "geometry": { "type": "MultiLineString", "coordinates": [ [ [ 113.988163138013832, 62.536254883811033 ], [ 113.988296867199608, 62.536222778014583 ] ] ] } },
{ "type": "Feature", "properties": { }, "geometry": { "type": "MultiLineString", "coordinates": [ [ [ 113.957022314101806, 62.533053477250775 ], [ 113.956921769898912, 62.533025058674646 ] ] ] } },
{ "type": "Feature", "properties": { }, "geometry": { "type": "MultiLineString", "coordinates": [ [ [ 113.96810888628363, 62.528366480630147 ], [ 113.968103580283667, 62.528325291681199 ] ] ] } },
{ "type": "Feature", "properties": { }, "geometry": { "type": "MultiLineString", "coordinates": [ [ [ 113.977500236440051, 62.53471191700519 ], [ 113.977504912914611, 62.534703913039124 ], [ 113.977651142676592, 62.53468745544599 ] ] ] } },
{ "type": "Feature", "properties": { }, "geometry": { "type": "MultiLineString", "coordinates": [ [ [ 113.945453975108819, 62.554885059107676 ], [ 113.94537942131258, 62.554871209548423 ] ] ] } },
{ "type": "Feature", "properties": { }, "geometry": { "type": "MultiLineString", "coordinates": [ [ [ 113.981784426723706, 62.543044315471988 ], [ 113.981935602756849, 62.542999349370518 ] ] ] } },
{ "type": "Feature", "properties": { }, "geometry": { "type": "MultiLineString", "coordinates": [ [ [ 113.966610975511472, 62.538370898614005 ], [ 113.966609086935208, 62.538344638410749 ] ] ] } },
{ "type": "Feature", "properties": { }, "geometry": { "type": "MultiLineString", "coordinates": [ [ [ 113.967219097067755, 62.536747352554329 ], [ 113.967187530864521, 62.536649056656515 ] ] ] } },
{ "type": "Feature", "properties": { }, "geometry": { "type": "MultiLineString", "coordinates": [ [ [ 113.983572728579176, 62.538759495662909 ], [ 113.983453028817053, 62.538806710069451 ] ] ] } },
{ "type": "Feature", "properties": { }, "geometry": { "type": "MultiLineString", "coordinates": [ [ [ 114.019995630498684, 62.534645457107217 ], [ 114.019920267312614, 62.534638802124199 ] ] ] } },
{ "type": "Feature", "properties": { }, "geometry": { "type": "MultiLineString", "coordinates": [ [ [ 113.970079750511061, 62.520197219179487 ], [ 113.970083797460205, 62.520193352094758 ], [ 113.970403596373856, 62.520212687518388 ] ] ] } },
{ "type": "Feature", "properties": { }, "geometry": { "type": "MultiLineString", "coordinates": [ [ [ 113.972852270395506, 62.523184227367935 ], [ 113.972891211039382, 62.52321723248641 ] ] ] } }
]
}
