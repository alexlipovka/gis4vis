var json__8 = {
"type": "FeatureCollection",
"name": "_8",
"crs": { "type": "name", "properties": { "name": "urn:ogc:def:crs:OGC:1.3:CRS84" } },
"features": [
{ "type": "Feature", "properties": { "Name      ": "ПНС-1", "H_geo     ": 312.0 }, "geometry": { "type": "Point", "coordinates": [ 113.948906112650874, 62.534299128193695 ] } },
{ "type": "Feature", "properties": { "Name      ": "ПНС-2", "H_geo     ": 332.05 }, "geometry": { "type": "Point", "coordinates": [ 113.976495963529828, 62.528476917375357 ] } }
]
}
