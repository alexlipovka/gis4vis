var json__11 = {
"type": "FeatureCollection",
"name": "_11",
"crs": { "type": "name", "properties": { "name": "urn:ogc:def:crs:OGC:1.3:CRS84" } },
"features": [
{ "type": "Feature", "properties": { "Name_pred ": "АК \"Алроса\" ПТВС", "Name      ": "Кот. Северо-Восточная", "H_geo     ": 382.64 }, "geometry": { "type": "Point", "coordinates": [ 113.984690405997313, 62.550634143739103 ] } },
{ "type": "Feature", "properties": { "Name_pred ": null, "Name      ": "Кот. Промзона", "H_geo     ": 356.56 }, "geometry": { "type": "Point", "coordinates": [ 113.967577926557482, 62.529123979575509 ] } },
{ "type": "Feature", "properties": { "Name_pred ": "ПАО «Якутскэнерго»", "Name      ": "Кот. ПАО «Якутскэнерго»", "H_geo     ": 376.0 }, "geometry": { "type": "Point", "coordinates": [ 113.978892926534783, 62.559314040238064 ] } },
{ "type": "Feature", "properties": { "Name_pred ": "МУП «Коммунальщик»", "Name      ": "Электрокотельная «Пеледуй»", "H_geo     ": 347.88 }, "geometry": { "type": "Point", "coordinates": [ 114.030118579126011, 62.536593658419505 ] } },
{ "type": "Feature", "properties": { "Name_pred ": "МУП «Коммунальщик»", "Name      ": "Кот. \"ПАКУ\"", "H_geo     ": 344.76 }, "geometry": { "type": "Point", "coordinates": [ 114.031264675120283, 62.538171698784495 ] } },
{ "type": "Feature", "properties": { "Name_pred ": "МУП «Коммунальщик»", "Name      ": "Кот. \"ПАКУ\" гвс", "H_geo     ": 344.76 }, "geometry": { "type": "Point", "coordinates": [ 114.031221147934062, 62.53813275814062 ] } },
{ "type": "Feature", "properties": { "Name_pred ": "МУП «Коммунальщик»", "Name      ": "Электробойлерная ул. Экспедиционная", "H_geo     ": 286.7 }, "geometry": { "type": "Point", "coordinates": [ 113.976667913901849, 62.517842164581097 ] } }
]
}
